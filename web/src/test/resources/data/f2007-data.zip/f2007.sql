-- MySQL dump 10.11
--
-- Host: localhost    Database: f2007
-- ------------------------------------------------------
-- Server version	5.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
CREATE TABLE `Account` (
  `id` bigint(20) NOT NULL auto_increment,
  `balance` decimal(19,2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
INSERT INTO `Account` VALUES (1,'454.00'),(4,'0.00'),(8,'875.00'),(9,'46.00'),(10,'0.00'),(11,'-60.00'),(12,'345.00'),(13,'240.00'),(14,'423.00'),(15,'-40.00'),(16,'30.00'),(17,'-20.00'),(18,'100.00'),(19,'20.00'),(20,'20.00'),(21,'635.00'),(22,'0.00'),(23,'500.00');
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PersistentRole`
--

DROP TABLE IF EXISTS `PersistentRole`;
CREATE TABLE `PersistentRole` (
  `id` bigint(20) NOT NULL auto_increment,
  `role` int(11) default NULL,
  `player_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK7ED22BCD872AC06E` (`player_id`),
  CONSTRAINT `FK7ED22BCD872AC06E` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PersistentRole`
--

LOCK TABLES `PersistentRole` WRITE;
/*!40000 ALTER TABLE `PersistentRole` DISABLE KEYS */;
INSERT INTO `PersistentRole` VALUES (1,1,1),(2,0,1),(3,2,1),(4,0,5),(5,0,6),(6,0,7),(7,0,8),(8,0,9),(9,0,10),(10,0,11),(11,0,12),(12,0,13),(13,0,14),(14,0,15),(15,0,16),(16,0,17),(17,0,18),(18,0,19),(19,0,20);
/*!40000 ALTER TABLE `PersistentRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WBC`
--

DROP TABLE IF EXISTS `WBC`;
CREATE TABLE `WBC` (
  `id` bigint(20) NOT NULL auto_increment,
  `previousRace_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK14ED847545097` (`previousRace_id`),
  CONSTRAINT `FK14ED847545097` FOREIGN KEY (`previousRace_id`) REFERENCES `race` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WBC`
--

LOCK TABLES `WBC` WRITE;
/*!40000 ALTER TABLE `WBC` DISABLE KEYS */;
INSERT INTO `WBC` VALUES (1,NULL);
/*!40000 ALTER TABLE `WBC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WBCEntry`
--

DROP TABLE IF EXISTS `WBCEntry`;
CREATE TABLE `WBCEntry` (
  `id` bigint(20) NOT NULL auto_increment,
  `points` int(11) NOT NULL,
  `player_id` bigint(20) NOT NULL,
  `race_id` bigint(20) NOT NULL,
  `wbc_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK6736507AAFDCD6F0` (`wbc_id`),
  KEY `FK6736507A872AC06E` (`player_id`),
  KEY `FK6736507A51EAFF6E` (`race_id`),
  CONSTRAINT `FK6736507A51EAFF6E` FOREIGN KEY (`race_id`) REFERENCES `race` (`id`),
  CONSTRAINT `FK6736507A872AC06E` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`),
  CONSTRAINT `FK6736507AAFDCD6F0` FOREIGN KEY (`wbc_id`) REFERENCES `wbc` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WBCEntry`
--

LOCK TABLES `WBCEntry` WRITE;
/*!40000 ALTER TABLE `WBCEntry` DISABLE KEYS */;
/*!40000 ALTER TABLE `WBCEntry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_entry`
--

DROP TABLE IF EXISTS `account_entry`;
CREATE TABLE `account_entry` (
  `DTYPE` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL auto_increment,
  `amount` decimal(19,2) NOT NULL,
  `date` datetime NOT NULL,
  `message` varchar(50) default NULL,
  `to_account_id` bigint(20) default NULL,
  `from_account_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKDFDBDFE07EE6EBBA` (`from_account_id`),
  KEY `FKDFDBDFE0D4A93849` (`to_account_id`),
  CONSTRAINT `FKDFDBDFE07EE6EBBA` FOREIGN KEY (`from_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKDFDBDFE0D4A93849` FOREIGN KEY (`to_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_entry`
--

LOCK TABLES `account_entry` WRITE;
/*!40000 ALTER TABLE `account_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_entry_link`
--

DROP TABLE IF EXISTS `account_entry_link`;
CREATE TABLE `account_entry_link` (
  `Account_id` bigint(20) NOT NULL,
  `entries_id` bigint(20) NOT NULL,
  KEY `FKDD6274F92A653C05` (`Account_id`),
  KEY `FKDD6274F944377F70` (`entries_id`),
  CONSTRAINT `FKDD6274F92A653C05` FOREIGN KEY (`Account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKDD6274F944377F70` FOREIGN KEY (`entries_id`) REFERENCES `account_entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_entry_link`
--

LOCK TABLES `account_entry_link` WRITE;
/*!40000 ALTER TABLE `account_entry_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_entry_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid`
--

DROP TABLE IF EXISTS `bid`;
CREATE TABLE `bid` (
  `id` bigint(20) NOT NULL auto_increment,
  `polePositionTimeMillis` int(11) NOT NULL,
  `grid_id` bigint(20) NOT NULL,
  `podium_id` bigint(20) NOT NULL,
  `fastestLap_id` bigint(20) NOT NULL,
  `firstCrash_id` bigint(20) NOT NULL,
  `player_id` bigint(20) NOT NULL,
  `selectedDriver_id` bigint(20) NOT NULL,
  `race_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `selectedDriver_id` (`selectedDriver_id`),
  UNIQUE KEY `firstCrash_id` (`firstCrash_id`),
  UNIQUE KEY `grid_id` (`grid_id`),
  UNIQUE KEY `podium_id` (`podium_id`),
  UNIQUE KEY `fastestLap_id` (`fastestLap_id`),
  KEY `FK17CFD588C2E5A` (`podium_id`),
  KEY `FK17CFD7A12CC2C` (`selectedDriver_id`),
  KEY `FK17CFD872AC06E` (`player_id`),
  KEY `FK17CFD51EAFF6E` (`race_id`),
  KEY `FK17CFD829F02C6` (`grid_id`),
  KEY `FK17CFD9C9F5404` (`firstCrash_id`),
  KEY `FK17CFD8CBBEA10` (`fastestLap_id`),
  CONSTRAINT `FK17CFD51EAFF6E` FOREIGN KEY (`race_id`) REFERENCES `race` (`id`),
  CONSTRAINT `FK17CFD588C2E5A` FOREIGN KEY (`podium_id`) REFERENCES `bid_podium` (`id`),
  CONSTRAINT `FK17CFD7A12CC2C` FOREIGN KEY (`selectedDriver_id`) REFERENCES `bid_select_driver` (`id`),
  CONSTRAINT `FK17CFD829F02C6` FOREIGN KEY (`grid_id`) REFERENCES `bid_grid` (`id`),
  CONSTRAINT `FK17CFD872AC06E` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`),
  CONSTRAINT `FK17CFD8CBBEA10` FOREIGN KEY (`fastestLap_id`) REFERENCES `bid_fastest_lap` (`id`),
  CONSTRAINT `FK17CFD9C9F5404` FOREIGN KEY (`firstCrash_id`) REFERENCES `bid_first_crash` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid`
--

LOCK TABLES `bid` WRITE;
/*!40000 ALTER TABLE `bid` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_fastest_lap`
--

DROP TABLE IF EXISTS `bid_fastest_lap`;
CREATE TABLE `bid_fastest_lap` (
  `id` bigint(20) NOT NULL auto_increment,
  `pointsDriver` int(11) NOT NULL,
  `driver_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK496CB744912DE70E` (`driver_id`),
  CONSTRAINT `FK496CB744912DE70E` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid_fastest_lap`
--

LOCK TABLES `bid_fastest_lap` WRITE;
/*!40000 ALTER TABLE `bid_fastest_lap` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_fastest_lap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_first_crash`
--

DROP TABLE IF EXISTS `bid_first_crash`;
CREATE TABLE `bid_first_crash` (
  `DTYPE` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL auto_increment,
  `pointsCrash1` int(11) NOT NULL,
  `crash1_id` bigint(20) NOT NULL,
  `crash3_id` bigint(20) default NULL,
  `crash2_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKE6081D1650A5CE8C` (`crash1_id`),
  KEY `FKE6081D1650A6B74A` (`crash3_id`),
  KEY `FKE6081D1650A642EB` (`crash2_id`),
  CONSTRAINT `FKE6081D1650A5CE8C` FOREIGN KEY (`crash1_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FKE6081D1650A642EB` FOREIGN KEY (`crash2_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FKE6081D1650A6B74A` FOREIGN KEY (`crash3_id`) REFERENCES `driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid_first_crash`
--

LOCK TABLES `bid_first_crash` WRITE;
/*!40000 ALTER TABLE `bid_first_crash` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_first_crash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_grid`
--

DROP TABLE IF EXISTS `bid_grid`;
CREATE TABLE `bid_grid` (
  `DTYPE` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL auto_increment,
  `pointsPosition1` int(11) NOT NULL,
  `pointsPosition2` int(11) NOT NULL,
  `pointsPosition3` int(11) NOT NULL,
  `pointsPosition4` int(11) NOT NULL,
  `pointsPosition5` int(11) NOT NULL,
  `pointsPosition6` int(11) NOT NULL,
  `position7_id` bigint(20) default NULL,
  `position1_id` bigint(20) NOT NULL,
  `position3_id` bigint(20) NOT NULL,
  `position2_id` bigint(20) NOT NULL,
  `position6_id` bigint(20) NOT NULL,
  `position4_id` bigint(20) NOT NULL,
  `position5_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK26B15D48E495E76D` (`position2_id`),
  KEY `FK26B15D48E497B8E9` (`position6_id`),
  KEY `FK26B15D48E4965BCC` (`position3_id`),
  KEY `FK26B15D48E496D02B` (`position4_id`),
  KEY `FK26B15D48E4982D48` (`position7_id`),
  KEY `FK26B15D48E495730E` (`position1_id`),
  KEY `FK26B15D48E497448A` (`position5_id`),
  CONSTRAINT `FK26B15D48E495730E` FOREIGN KEY (`position1_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E495E76D` FOREIGN KEY (`position2_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E4965BCC` FOREIGN KEY (`position3_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E496D02B` FOREIGN KEY (`position4_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E497448A` FOREIGN KEY (`position5_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E497B8E9` FOREIGN KEY (`position6_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK26B15D48E4982D48` FOREIGN KEY (`position7_id`) REFERENCES `driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid_grid`
--

LOCK TABLES `bid_grid` WRITE;
/*!40000 ALTER TABLE `bid_grid` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_grid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_podium`
--

DROP TABLE IF EXISTS `bid_podium`;
CREATE TABLE `bid_podium` (
  `DTYPE` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL auto_increment,
  `pointsPosition1` int(11) NOT NULL,
  `pointsPosition2` int(11) NOT NULL,
  `pointsPosition3` int(11) NOT NULL,
  `position3_id` bigint(20) NOT NULL,
  `position2_id` bigint(20) NOT NULL,
  `position4_id` bigint(20) default NULL,
  `position1_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK4EFE5DDEE495E76D` (`position2_id`),
  KEY `FK4EFE5DDEE4965BCC` (`position3_id`),
  KEY `FK4EFE5DDEE496D02B` (`position4_id`),
  KEY `FK4EFE5DDEE495730E` (`position1_id`),
  CONSTRAINT `FK4EFE5DDEE495730E` FOREIGN KEY (`position1_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK4EFE5DDEE495E76D` FOREIGN KEY (`position2_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK4EFE5DDEE4965BCC` FOREIGN KEY (`position3_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK4EFE5DDEE496D02B` FOREIGN KEY (`position4_id`) REFERENCES `driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid_podium`
--

LOCK TABLES `bid_podium` WRITE;
/*!40000 ALTER TABLE `bid_podium` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_podium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_select_driver`
--

DROP TABLE IF EXISTS `bid_select_driver`;
CREATE TABLE `bid_select_driver` (
  `id` bigint(20) NOT NULL auto_increment,
  `endPosition` int(11) NOT NULL,
  `pointsEndPosition` int(11) NOT NULL,
  `pointsStartPosition` int(11) NOT NULL,
  `startPosition` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bid_select_driver`
--

LOCK TABLES `bid_select_driver` WRITE;
/*!40000 ALTER TABLE `bid_select_driver` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_select_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
CREATE TABLE `driver` (
  `id` bigint(20) NOT NULL auto_increment,
  `active` bit(1) NOT NULL,
  `name` varchar(255) default NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES (1,'','Kimi Raikonen',1),(2,'','Felipe Massa',2),(3,'','Lewis Hamilton',22),(4,'','Fernando Alonso',5),(5,'','Nick Heidfeld',3),(6,'','Robert Kubica',4),(7,'','Jenson Button',16),(8,'','Nelsinho Piquet',6),(9,'','Nico Rosberg',7),(10,'','Kazuki Nakajima',8),(11,'','David Coulthard',9),(12,'','Mark Webber',10),(13,'','Jarno Trulli',11),(14,'','Timo Glock',12),(15,'','Sebastien Bourdais',14),(16,'','Sebastian Vettel',15),(17,'','Rubens Barrichello',17),(18,'','Takuma Sato',18),(19,'','Anthony Davidson',19),(20,'','Adrian Sutil',20),(21,'','Giancarlo Fisichella',21),(22,'','Heikki Kovalainen',23);
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
CREATE TABLE `player` (
  `id` bigint(20) NOT NULL auto_increment,
  `emailAddress` varchar(40) default NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `playername` varchar(15) NOT NULL,
  `sms` varchar(8) default NULL,
  `account_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `playername` (`playername`),
  UNIQUE KEY `account_id` (`account_id`),
  KEY `FKC53E9AE12A653C05` (`account_id`),
  CONSTRAINT `FKC53E9AE12A653C05` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (1,'flemming@bregnvig.dk','Flemming','Bregnvig','flb','flb','28712234',1),(4,'','My','Bookie','secret','bookie','',4),(5,'','Michael','Bartrup','skalændres','bartrup','',8),(6,'','Thomas T.','Pedersen','skalændres','ttp','',9),(7,'','Peter','Thorup','skalændres','peter','',10),(8,'','Niels-Henrik','Rasmussen','skalændres','nra','',11),(9,'','Thomas','Knudsen','skalændres','killerkim','',12),(10,'','Palle','Christiansen','skalændres','palle','',13),(11,'','Allan','Willems','skalændres','wilems','',14),(12,'','Morten','Mathiesen','skalændres','mmathiesen','',15),(13,'','Frank','Vilhelmsen','skalændres','frankie','',16),(14,'','Thorbjørn N.','Larsen','skalændres','tnl','',17),(15,'','Thomas','Ringling','skalændres','ringling','',18),(16,'','Jesper','Dalsten','skalændres','dalsten','',19),(17,'','Vagn','Søndergaard','skalændres','vagn','',20),(18,'','Mogens','Højte','skalændres','mhoejte','',21),(19,'','Brian','Falk','skalændres','falk','',22),(20,'','Nino Stokbro','Ag','skalændres','nino','',23);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `race`
--

DROP TABLE IF EXISTS `race`;
CREATE TABLE `race` (
  `id` bigint(20) NOT NULL auto_increment,
  `close` datetime NOT NULL,
  `completed` bit(1) NOT NULL,
  `name` varchar(25) NOT NULL,
  `open` datetime NOT NULL,
  `season_id` bigint(20) NOT NULL,
  `raceResult_id` bigint(20) default NULL,
  `selectedDriver_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK354AD1B52FB2D3` (`selectedDriver_id`),
  KEY `FK354AD1A4EC036E` (`raceResult_id`),
  KEY `FK354AD167D9A92E` (`season_id`),
  CONSTRAINT `FK354AD167D9A92E` FOREIGN KEY (`season_id`) REFERENCES `season` (`id`),
  CONSTRAINT `FK354AD1A4EC036E` FOREIGN KEY (`raceResult_id`) REFERENCES `race_result` (`id`),
  CONSTRAINT `FK354AD1B52FB2D3` FOREIGN KEY (`selectedDriver_id`) REFERENCES `driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `race`
--

LOCK TABLES `race` WRITE;
/*!40000 ALTER TABLE `race` DISABLE KEYS */;
INSERT INTO `race` VALUES (1,'2008-03-14 00:00:00','\0','Albert Park','2008-03-10 00:00:00',1,NULL,12),(2,'2008-03-21 03:00:00','\0','Sepang','2008-03-17 00:00:00',1,NULL,20),(3,'2008-04-04 09:00:00','\0','Bahrain','2008-03-24 00:00:00',1,NULL,8),(4,'2008-04-25 10:00:00','\0','Catalunya','2008-04-07 00:00:00',1,NULL,4),(5,'2008-05-09 09:00:00','\0','Istanbul','2008-04-28 00:00:00',1,NULL,10),(6,'2008-05-22 10:00:00','\0','Monaco','2008-05-12 00:00:00',1,NULL,1),(7,'2008-06-06 16:00:00','\0','Montreal','2008-05-26 00:00:00',1,NULL,9),(8,'2008-06-20 10:00:00','\0','Magny-Cours','2008-06-09 00:00:00',1,NULL,15),(9,'2008-07-04 11:00:00','\0','Silverstone','2008-06-23 00:00:00',1,NULL,3),(10,'2008-07-18 10:00:00','\0','Hokenheim','2008-07-07 00:00:00',1,NULL,5),(11,'2008-08-01 10:00:00','\0','Hungaroring','2008-07-21 00:00:00',1,NULL,22),(12,'2008-08-22 10:00:00','\0','Valensia','2008-08-04 00:00:00',1,NULL,8),(13,'2008-09-05 10:00:00','\0','Spa-Francorchamps','2008-08-25 00:00:00',1,NULL,11),(14,'2008-09-12 10:00:00','\0','Monza','2008-09-08 00:00:00',1,NULL,13),(15,'2008-09-26 10:00:00','\0','Singapore','2008-09-15 00:00:00',1,NULL,21),(16,'2008-10-10 03:00:00','\0','Fuji','2008-09-29 00:00:00',1,NULL,18),(17,'2008-10-17 04:00:00','\0','Shanghai','2008-10-13 00:00:00',1,NULL,10),(18,'2008-10-31 14:00:00','\0','Interlagos','2008-10-20 00:00:00',1,NULL,2);
/*!40000 ALTER TABLE `race` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `race_bid`
--

DROP TABLE IF EXISTS `race_bid`;
CREATE TABLE `race_bid` (
  `race_id` bigint(20) NOT NULL,
  `bids_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`race_id`,`bids_id`),
  UNIQUE KEY `bids_id` (`bids_id`),
  KEY `FKFC2E268F51EAFF6E` (`race_id`),
  KEY `FKFC2E268F210660D` (`bids_id`),
  CONSTRAINT `FKFC2E268F210660D` FOREIGN KEY (`bids_id`) REFERENCES `bid` (`id`),
  CONSTRAINT `FKFC2E268F51EAFF6E` FOREIGN KEY (`race_id`) REFERENCES `race` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `race_bid`
--

LOCK TABLES `race_bid` WRITE;
/*!40000 ALTER TABLE `race_bid` DISABLE KEYS */;
/*!40000 ALTER TABLE `race_bid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `race_result`
--

DROP TABLE IF EXISTS `race_result`;
CREATE TABLE `race_result` (
  `id` bigint(20) NOT NULL auto_increment,
  `polePositionTimeMillis` int(11) NOT NULL,
  `firstCrash_id` bigint(20) NOT NULL,
  `selectedDriver_id` bigint(20) NOT NULL,
  `player_id` bigint(20) NOT NULL,
  `fastestLap_id` bigint(20) NOT NULL,
  `grid_id` bigint(20) NOT NULL,
  `podium_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `selectedDriver_id` (`selectedDriver_id`),
  UNIQUE KEY `podium_id` (`podium_id`),
  UNIQUE KEY `grid_id` (`grid_id`),
  UNIQUE KEY `firstCrash_id` (`firstCrash_id`),
  UNIQUE KEY `fastestLap_id` (`fastestLap_id`),
  KEY `FK99B6DD4BF6D0B21C` (`podium_id`),
  KEY `FK99B6DD4B7A12CC2C` (`selectedDriver_id`),
  KEY `FK99B6DD4B872AC06E` (`player_id`),
  KEY `FK99B6DD4B75205F9C` (`grid_id`),
  KEY `FK99B6DD4BF0CF155C` (`firstCrash_id`),
  KEY `FK99B6DD4B8CBBEA10` (`fastestLap_id`),
  CONSTRAINT `FK99B6DD4B75205F9C` FOREIGN KEY (`grid_id`) REFERENCES `bid_grid` (`id`),
  CONSTRAINT `FK99B6DD4B7A12CC2C` FOREIGN KEY (`selectedDriver_id`) REFERENCES `bid_select_driver` (`id`),
  CONSTRAINT `FK99B6DD4B872AC06E` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`),
  CONSTRAINT `FK99B6DD4B8CBBEA10` FOREIGN KEY (`fastestLap_id`) REFERENCES `bid_fastest_lap` (`id`),
  CONSTRAINT `FK99B6DD4BF0CF155C` FOREIGN KEY (`firstCrash_id`) REFERENCES `bid_first_crash` (`id`),
  CONSTRAINT `FK99B6DD4BF6D0B21C` FOREIGN KEY (`podium_id`) REFERENCES `bid_podium` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `race_result`
--

LOCK TABLES `race_result` WRITE;
/*!40000 ALTER TABLE `race_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `race_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season`
--

DROP TABLE IF EXISTS `season`;
CREATE TABLE `season` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `WBC_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FKC9FA6AE3AFDCD6F0` (`WBC_id`),
  CONSTRAINT `FKC9FA6AE3AFDCD6F0` FOREIGN KEY (`WBC_id`) REFERENCES `wbc` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `season`
--

LOCK TABLES `season` WRITE;
/*!40000 ALTER TABLE `season` DISABLE KEYS */;
INSERT INTO `season` VALUES (1,'F1 2008',1);
/*!40000 ALTER TABLE `season` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_driver`
--

DROP TABLE IF EXISTS `season_driver`;
CREATE TABLE `season_driver` (
  `season_id` bigint(20) NOT NULL,
  `drivers_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`season_id`,`drivers_id`),
  KEY `FK9491B504617DB0B` (`drivers_id`),
  KEY `FK9491B50467D9A92E` (`season_id`),
  CONSTRAINT `FK9491B504617DB0B` FOREIGN KEY (`drivers_id`) REFERENCES `driver` (`id`),
  CONSTRAINT `FK9491B50467D9A92E` FOREIGN KEY (`season_id`) REFERENCES `season` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `season_driver`
--

LOCK TABLES `season_driver` WRITE;
/*!40000 ALTER TABLE `season_driver` DISABLE KEYS */;
INSERT INTO `season_driver` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22);
/*!40000 ALTER TABLE `season_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_player`
--

DROP TABLE IF EXISTS `season_player`;
CREATE TABLE `season_player` (
  `season_id` bigint(20) NOT NULL,
  `players_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`season_id`,`players_id`),
  KEY `FKA8B3B7BD73B9DBFD` (`players_id`),
  KEY `FKA8B3B7BD67D9A92E` (`season_id`),
  CONSTRAINT `FKA8B3B7BD67D9A92E` FOREIGN KEY (`season_id`) REFERENCES `season` (`id`),
  CONSTRAINT `FKA8B3B7BD73B9DBFD` FOREIGN KEY (`players_id`) REFERENCES `player` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `season_player`
--

LOCK TABLES `season_player` WRITE;
/*!40000 ALTER TABLE `season_player` DISABLE KEYS */;
INSERT INTO `season_player` VALUES (1,1),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20);
/*!40000 ALTER TABLE `season_player` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2008-03-10 21:08:28
